// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBzG3UQ7JC__Nh5ZD3eW4jxx1OFHMHWUpI",
    authDomain: "loginsite-5918d.firebaseapp.com",
    databaseURL: "https://loginsite-5918d-default-rtdb.firebaseio.com",
    projectId: "loginsite-5918d",
    storageBucket: "loginsite-5918d.firebasestorage.app",
    messagingSenderId: "897074198222",
    appId: "1:897074198222:web:d52a297b79cfcf9878c29f",
    measurementId: "G-6HD8DL19Q0"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Reference the SignInForms node in the database
var contactFormDB = firebase.database().ref('SignInForms');

// Listen for the Register button click event
document.getElementById('registerForm').addEventListener('submit', submitForm);

function submitForm(e) {
    e.preventDefault(); // Prevent form submission

    // Get the values from the input fields
    var firstname = getElementVal('firstName');
    var lastname = getElementVal('lastname');
    var email = getElementVal('email');
    var password = getElementVal('password');

    // Save the data to Firebase
    saveMessages(firstname, lastname, email, password);

    // Optionally, clear the form
    clearForm();
}

// Function to save messages to Firebase
const saveMessages = (firstname, lastname, email, password) => {
    var newContactForm = contactFormDB.push();
    newContactForm.set({
        firstname: firstname,
        lastname: lastname,
        email: email,
        password: password
    });
};

// Function to get input field values by ID
const getElementVal = (id) => {
    return document.getElementById(id).value;
};

// Function to clear the form inputs
const clearForm = () => {
    document.getElementById('firstName').value = "";
    document.getElementById('lastname').value = "";
    document.getElementById('email').value = "";
    document.getElementById('password').value = "";
};
